$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("sample.feature");
formatter.feature({
  "line": 5,
  "name": "To test my cucumber test is running",
  "description": "",
  "id": "to-test-my-cucumber-test-is-running",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@smokeTest"
    }
  ]
});
formatter.scenario({
  "line": 8,
  "name": "cucumber setup",
  "description": "",
  "id": "to-test-my-cucumber-test-is-running;cucumber-setup",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 10,
  "name": "follow the link http://test-app.d6.dev.devcaz.com/admin/login..",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "entered login..",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "entered a password..",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "pressed the button Sigh in..",
  "keyword": "Then "
});
formatter.step({
  "line": 14,
  "name": "open the list of players..",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "we get the login of the top player in the table..",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "sort the players by name..",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "we get the login of the top player in the table after sorting..",
  "keyword": "When "
});
formatter.step({
  "line": 18,
  "name": "compare player names.",
  "keyword": "Then "
});
formatter.match({
  "location": "TestDevcaz.givenUrl()"
});
formatter.result({
  "duration": 10134858400,
  "status": "passed"
});
formatter.match({
  "location": "TestDevcaz.setLogin()"
});
formatter.result({
  "duration": 87563100,
  "status": "passed"
});
formatter.match({
  "location": "TestDevcaz.setPassword()"
});
formatter.result({
  "duration": 89399200,
  "status": "passed"
});
formatter.match({
  "location": "TestDevcaz.pressButton()"
});
formatter.result({
  "duration": 2498025200,
  "status": "passed"
});
formatter.match({
  "location": "TestDevcaz.getPlayers()"
});
formatter.result({
  "duration": 1421641600,
  "status": "passed"
});
formatter.match({
  "location": "TestDevcaz.getPlayer()"
});
formatter.result({
  "duration": 16976500,
  "status": "passed"
});
formatter.match({
  "location": "TestDevcaz.sortByName()"
});
formatter.result({
  "duration": 115387800,
  "status": "passed"
});
formatter.match({
  "location": "TestDevcaz.getPlayerNew()"
});
formatter.result({
  "duration": 12692100,
  "status": "passed"
});
formatter.match({
  "location": "TestDevcaz.comparePlayer()"
});
formatter.result({
  "duration": 116000,
  "status": "passed"
});
});