package com.my.testtest;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestDevcaz {

    String url = "http://test-app.d6.dev.devcaz.com/admin/login";
    String user = "admin1";
    String password = "[9k<k8^z!+$$GkuP";

    WebDriver driver = null;
    WebElement element = null;
    WebElement element1 = null;

   

    @Given("^follow the link http://test-app.d6.dev.devcaz.com/admin/login..$")
    public void givenUrl() {
        System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\dist\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().setSize(new Dimension(1920, 1080));
        driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
        driver.get(url);
    }

    @When("^entered login..$")
    public void setLogin() {
        driver.findElement(By.id("UserLogin_username")).sendKeys(user);
    }

    @When("^entered a password..$")
    public void setPassword() {
        driver.findElement(By.id("UserLogin_password")).sendKeys(password);
    }

    @Then("^pressed the button Sigh in..$")
    public void pressButton() {
        driver.findElement(By.name("yt0")).click();
    }

    @When("^open the list of players..$")
    public void getPlayers() {
        driver.findElement(By.partialLinkText("Players online / total")).click();
    }
    

    @When("^we get the login of the top player in the table..$")
    public void getPlayer() {
        element = driver.findElement(By.xpath("//*[@id=\"payment-system-transaction-grid\"]/table/tbody/tr[1]/td[2]/a"));
    }

    @When("^sort the players by name..$")
    public void sortByName() {
        driver.findElement(By.partialLinkText("Username")).click();
    }

    @When("^we get the login of the top player in the table after sorting..$")
    public void getPlayerNew() {
        element1 = driver.findElement(By.xpath("//*[@id=\"payment-system-transaction-grid\"]/table/tbody/tr[1]/td[2]/a"));

    }

    @Then("^compare player names.$")
    public void comparePlayer() {
        if (this.element == this.element1) {
            System.out.print("Сортировка не прошла");
        } else {
            System.out.print("Сортировка прошла успешно");
        }
    }
}
